from django.db.models import Count, Avg, Q
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import HealthRecord
from .serializers import HealthRecordSerializer
from django.db.models import Avg
from django.db.models import Count
from django.db.models import Q


# ==========================
# Common Filter
# ==========================

def get_filtered_records(request):
    records = HealthRecord.objects.all()

    district = request.GET.get("district")
    month = request.GET.get("month")
    gender = request.GET.get("gender")
    search = request.GET.get("search")

    if district and district != "All":
        records = records.filter(district_name=district)

    if month and month != "All":
        records = records.filter(month=month)

    if gender and gender != "All":
        records = records.filter(gender__iexact=gender)

    if search:
        records = records.filter(
            Q(facility_name__icontains=search) |
            Q(district_name__icontains=search) |
            Q(unique_id__icontains=search)
        )

    return records
# ==========================
# Dashboard Summary
# ==========================

@api_view(["GET"])
def dashboard_summary(request):
    records = get_filtered_records(request)

    # Executed in a single database query
    data = records.aggregate(
        total_records=Count("id"),
        male=Count("id", filter=Q(gender__iexact="M")),
        female=Count("id", filter=Q(gender__iexact="F")),
        average_age=Avg("age")
    )

    summary = {
        "total_records": data["total_records"] or 0,
        "male": data["male"] or 0,
        "female": data["female"] or 0,
        "average_age": round(data["average_age"] or 0, 1),
    }

    return Response(summary)


# ==========================
# Records
# ==========================

@api_view(["GET"])
def all_records(request):
    records = get_filtered_records(request)
    serializer = HealthRecordSerializer(records[:200], many=True)
    return Response(serializer.data)


# ==========================
# Gender Chart
# ==========================

@api_view(["GET"])
def gender_chart(request):
    records = get_filtered_records(request)
    data = (
        records
        .values("gender")
        .annotate(count=Count("id"))
        .order_by("gender")
    )
    return Response(data)


# ==========================
# District Chart
# ==========================

@api_view(["GET"])
def district_chart(request):
    records = get_filtered_records(request)

    data = (
        records
        .values("district_name")
        .annotate(
            total=Count("id"),
            male=Count("id", filter=Q(gender__iexact="M")),
            female=Count("id", filter=Q(gender__iexact="F")),
            avg_rbc=Avg("red_blood_cells"),
            avg_wbc=Avg("white_blood_cells"),
            avg_platelets=Avg("thrombocytes"),
        )
        .order_by("district_name")
    )

    chart_data = [
        {
            "district_name": item["district_name"],
            "total": item["total"],
            "male": item["male"],
            "female": item["female"],
            "avg_rbc": round(item["avg_rbc"] or 0, 2),
            "avg_wbc": round(item["avg_wbc"] or 0, 2),
            "avg_platelets": round(item["avg_platelets"] or 0, 2),
        }
        for item in data
    ]

    return Response(chart_data)
# ==========================
# Map Data
# ==========================

@api_view(["GET"])
def map_data(request):
    records = get_filtered_records(request)

    data = (
        records
        .values("district_name")
        .annotate(
            total=Count("id"),
            male=Count("id", filter=Q(gender__iexact="M")),
            female=Count("id", filter=Q(gender__iexact="F")),
        )
        .order_by("district_name")
    )

    return Response([
        {
            "district": row["district_name"],
            "total": row["total"],
            "male": row["male"],
            "female": row["female"],
        }
        for row in data
    ])


# ==========================
# Monthly Chart
# ==========================

@api_view(["GET"])
def monthly_chart(request):
    records = get_filtered_records(request)

    data = (
        records
        .values("month")
        .annotate(count=Count("id"))
        .order_by("month")
    )

    return Response(data)


# ==========================
# Age Groups Chart (Database Aggregated)
# ==========================

@api_view(["GET"])
def age_group_chart(request):
    records = get_filtered_records(request).exclude(age__isnull=True)

    # Process buckets entirely in SQL instead of Python loop
    groups = records.aggregate(
        group_0_18=Count("id", filter=Q(age__lte=18)),
        group_19_35=Count("id", filter=Q(age__gte=19, age__lte=35)),
        group_36_50=Count("id", filter=Q(age__gte=36, age__lte=50)),
        group_51_65=Count("id", filter=Q(age__gte=51, age__lte=65)),
        group_65_plus=Count("id", filter=Q(age__gt=65)),
    )

    formatted_response = {
        "0-18": groups["group_0_18"] or 0,
        "19-35": groups["group_19_35"] or 0,
        "36-50": groups["group_36_50"] or 0,
        "51-65": groups["group_51_65"] or 0,
        "65+": groups["group_65_plus"] or 0,
    }

    return Response(formatted_response)

# ==========================
# Age Insights
# ==========================

@api_view(["GET"])
def age_insights(request):
    records = get_filtered_records(request).exclude(age__isnull=True)

    age_groups = {
        "0-18": records.filter(age__lte=18),
        "19-35": records.filter(age__gte=19, age__lte=35),
        "36-50": records.filter(age__gte=36, age__lte=50),
        "51-65": records.filter(age__gte=51, age__lte=65),
        "65+": records.filter(age__gt=65),
    }

    insights = {}

    for name, qs in age_groups.items():
        stats = qs.aggregate(
            patients=Count("id"),
            avg_rbc=Avg("red_blood_cells"),
            avg_wbc=Avg("white_blood_cells"),
            avg_platelets=Avg("thrombocytes"),
        )

        insights[name] = {
            "patients": stats["patients"] or 0,
            "avg_rbc": round(stats["avg_rbc"] or 0, 2),
            "avg_wbc": round(stats["avg_wbc"] or 0, 2),
            "avg_platelets": round(stats["avg_platelets"] or 0, 2),
        }

    highest_rbc = max(
        insights.items(),
        key=lambda x: x[1]["avg_rbc"]
    )

    highest_wbc = max(
        insights.items(),
        key=lambda x: x[1]["avg_wbc"]
    )

    highest_platelets = max(
        insights.items(),
        key=lambda x: x[1]["avg_platelets"]
    )

    largest_group = max(
        insights.items(),
        key=lambda x: x[1]["patients"]
    )

    return Response({
        "highest_rbc": {
            "group": highest_rbc[0],
            "value": highest_rbc[1]["avg_rbc"],
        },

        "highest_wbc": {
            "group": highest_wbc[0],
            "value": highest_wbc[1]["avg_wbc"],
        },

        "highest_platelets": {
            "group": highest_platelets[0],
            "value": highest_platelets[1]["avg_platelets"],
        },

        "largest_group": {
            "group": largest_group[0],
            "patients": largest_group[1]["patients"],
        }
    })
# ==========================
# Top Facilities Chart
# ==========================

@api_view(["GET"])
def top_facilities_chart(request):
    records = get_filtered_records(request)

    data = (
        records
        .values("facility_name")
        .annotate(count=Count("id"))
        .order_by("-count")[:10]
    )

    return Response(data)


# ==========================
# District Patients Chart
# ==========================

@api_view(["GET"])
def district_patient_chart(request):
    records = get_filtered_records(request)

    data = (
        records
        .values("district_name")
        .annotate(count=Count("id"))
        .order_by("-count")
    )

    return Response(data)


# ==========================
# Filter Dropdown Values
# ==========================

@api_view(["GET"])
def filters(request):
    # Filter out None/null values before distinct to keep dropdown options clean
    districts = list(
    HealthRecord.objects.exclude(
        district_name__isnull=True
    ).exclude(
        district_name=""
    )
        .values_list("district_name", flat=True)
        .distinct()
        .order_by("district_name")
    )

    months = list(
    HealthRecord.objects.exclude(month__isnull=True)
    .exclude(month="")
        .values_list("month", flat=True)
        .distinct()
        .order_by("month")
    )

    genders = list(
     HealthRecord.objects.exclude(gender__isnull=True)
    .exclude(gender="")
        .values_list("gender", flat=True)
        .distinct()
        .order_by("gender")
    )

    return Response({
        "districts": districts,
        "months": months,
        "genders": genders,
    })


# ==========================
# Filter Dashboard
# ==========================

@api_view(["GET"])
def filter_data(request):
    records = get_filtered_records(request)

    # Executed in a single aggregate query
    data = records.aggregate(
        total_records=Count("id"),
        male=Count("id", filter=Q(gender__iexact="M")),
        female=Count("id", filter=Q(gender__iexact="F")),
        average_age=Avg("age"),
        avg_rbc=Avg("red_blood_cells"),
        avg_wbc=Avg("white_blood_cells"),
        avg_platelets=Avg("thrombocytes"),
    )

    summary = {
        "total_records": data["total_records"] or 0,
        "male": data["male"] or 0,
        "female": data["female"] or 0,
        "average_age": round(data["average_age"] or 0, 1),
        "avg_rbc": round(data["avg_rbc"] or 0, 2),
        "avg_wbc": round(data["avg_wbc"] or 0, 2),
        "avg_platelets": round(data["avg_platelets"] or 0, 2),
    }

    serializer = HealthRecordSerializer(records[:200], many=True)

    return Response({
        "summary": summary,
        "records": serializer.data
    })





@api_view(["GET"])
def district_summary(request):

    qs = get_filtered_records(request)

    data = {
        "total_patients": qs.count(),

        "male": qs.filter(gender="M").count(),

        "female": qs.filter(gender="F").count(),

        "average_age": round(
            qs.aggregate(Avg("age"))["age__avg"] or 0,
            2,
        ),

        "average_rbc": round(
            qs.aggregate(Avg("red_blood_cells"))["red_blood_cells__avg"] or 0,
            2,
        ),

        "average_wbc": round(
            qs.aggregate(Avg("white_blood_cells"))["white_blood_cells__avg"] or 0,
            2,
        ),

        "average_platelets": round(
            qs.aggregate(Avg("thrombocytes"))["thrombocytes__avg"] or 0,
            2,
        ),

        "facilities": qs.values("facility_name").distinct().count(),
    }

    return Response(data)


@api_view(["GET"])
def rbc_trend(request):

    qs = get_filtered_records(request)

    data = (
        qs.values("month")
        .annotate(value=Avg("red_blood_cells"))
        .order_by("month")
    )

    return Response(data)


@api_view(["GET"])
def wbc_trend(request):

    qs = get_filtered_records(request)

    data = (
        qs.values("month")
        .annotate(value=Avg("white_blood_cells"))
        .order_by("month")
    )

    return Response(data)


@api_view(["GET"])
def platelet_trend(request):

    qs = get_filtered_records(request)

    data = (
        qs.values("month")
        .annotate(value=Avg("thrombocytes"))
        .order_by("month")
    )

    return Response(data)

@api_view(["GET"])
def facility_analysis(request):

    qs = get_filtered_records(request)

    data = (
        qs.values("facility_name")
        .annotate(
            patients=Count("id"),
            avg_rbc=Avg("red_blood_cells"),
            avg_wbc=Avg("white_blood_cells"),
            avg_platelets=Avg("thrombocytes"),
        )
        .order_by("-patients")[:10]
    )

    return Response(data)

@api_view(["GET"])
def district_insights(request):

    qs = get_filtered_records(request)

    highest_month = (
        qs.values("month")
        .annotate(total=Count("id"))
        .order_by("-total")
        .first()
    )

    age_groups = {
        "0-10": qs.filter(age__lte=10).count(),
        "11-20": qs.filter(age__gte=11, age__lte=20).count(),
        "21-40": qs.filter(age__gte=21, age__lte=40).count(),
        "41-60": qs.filter(age__gte=41, age__lte=60).count(),
        "60+": qs.filter(age__gt=60).count(),
    }

    largest = max(age_groups, key=age_groups.get)

    summary = (
        f"Most patients belong to the {largest} age group. "
        f"The highest patient load occurred during "
        f"{highest_month['month'] if highest_month else 'N/A'}."
    )

    return Response({
        "highest_month": highest_month["month"] if highest_month else "",
        "largest_age_group": largest,
        "summary": summary,
    })
from django.db.models import Count, Avg
from rest_framework.decorators import api_view
from rest_framework.response import Response


@api_view(["GET"])
def analytics_summary(request):

    qs = get_filtered_records(request)

    top_district = (
        qs.values("district_name")
        .annotate(total=Count("id"))
        .order_by("-total")
        .first()
    )

    top_facility = (
        qs.values("facility_name")
        .annotate(total=Count("id"))
        .order_by("-total")
        .first()
    )

    peak_month = (
        qs.values("month")
        .annotate(total=Count("id"))
        .order_by("-total")
        .first()
    )

    total_facilities = qs.values("facility_name").distinct().count()

    total_districts = qs.values("district_name").distinct().count()

    average_age = round(
        qs.aggregate(avg=Avg("age"))["avg"] or 0,
        1,
    )

    return Response({

        "average_age": average_age,

        "top_district":
            top_district["district_name"] if top_district else "-",

        "top_facility":
            top_facility["facility_name"] if top_facility else "-",

        "peak_month":
            peak_month["month"] if peak_month else "-",

        "facility_count":
            total_facilities,

        "district_count":
            total_districts,

        "total_patients":
            qs.count(),

    })
@api_view(["GET"])
def district_heatmap(request):

    qs = get_filtered_records(request)

    data = (

        qs.values("district_name")

        .annotate(

            patients=Count("id"),

            male=Count(
                "id",
                filter=Q(gender__iexact="M")
            ),

            female=Count(
                "id",
                filter=Q(gender__iexact="F")
            ),

            average_age=Avg("age"),

            facilities=Count(
                "facility_name",
                distinct=True
            ),

        )

        .order_by("district_name")

    )

    return Response(data)
    